<?php require('partials/header.php'); ?>
<?php require('partials/nav.php'); ?>

<div class="container">
  <h1>Halaman About</h1>
</div>

<?php require('partials/footer.php'); ?>