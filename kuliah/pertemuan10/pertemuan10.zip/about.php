<?php
require('functions.php');
$title = 'About';
require('views/about.view.php');
